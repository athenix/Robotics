package com.qualcomm.ftcrobotcontroller.opmodes.programs;

/**
 * Created by Sauhaarda on 4/11/2016.
 */
public class EdmundTest extends ProgramSkeleton{
    public void initProgram(){
        movementLib.climb(0.4,0.5);
    }
    public void loopProgram(){

    }
}
